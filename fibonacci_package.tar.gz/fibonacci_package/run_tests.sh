#!/bin/bash

make clean

make

make test

./test_fibonacci

make package
